
import './App.css';
import ConditionalRendering from './components/conditionalrendering';
import Count from './components/Quizapp';
function App (){
  return(
    <>
  <Count/>
  <ConditionalRendering/>
  </>
  );
}

export default App;